package com.example.buynow.data.model

data class Shop(
    val shopName: String = "",
    val shopImage: String = "",
    val shopAddress: String = ""
)